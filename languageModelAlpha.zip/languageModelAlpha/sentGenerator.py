import random

def genSentence(tokens):
    sentence = ""
    for _ in range(50):
        word = random.choice(tokens)
        sentence += word + " "
        if word == '.':
            break
    else: # this is True if the loop was not broken
        sentence += ' .'
            
    return sentence.strip()