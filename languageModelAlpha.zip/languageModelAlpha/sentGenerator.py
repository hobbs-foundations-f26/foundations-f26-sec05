import random

# this function returns one sentence
# I want e.g. genSentence([...], 15) to return 15 sentences
def genSentence(tokens, numSententences=1):
    sentence = ""
    for _ in range(numSententences):
        for _ in range(50):
            word = random.choice(tokens)
            sentence += word + " "
            if word == '.':
                break
        else: # this is True if the loop was not broken
            sentence += ' .'
            
    return sentence