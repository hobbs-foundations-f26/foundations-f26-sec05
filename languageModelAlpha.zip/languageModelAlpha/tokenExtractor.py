def tokenExtractor(sentences):
    tokens = []
    for sentence in sentences:
        words = sentence.split()
        for word in words:
            tokens.append(word)
    return tokens