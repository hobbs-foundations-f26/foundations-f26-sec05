def tokenExtractor(sentences):
    tokens = []
    for sentence in sentences:
        words = space_before_punctuation(sentence).split()
        for word in words:
            tokens.append(word)
    return tokens

import string # for string.punctuation
def space_before_punctuation(sentence):
    for p in string.punctuation:
        sentence = sentence.replace(p, " " + p + " ")
    return sentence

