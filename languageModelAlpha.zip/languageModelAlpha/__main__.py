import argparse

# note the . that preceeds the module names
# because these are *part of* languageModelAlpha
from .tokenExtractor import tokenExtractor
from .sentGenerator import genSentence

def get_filename():
    parser = argparse.ArgumentParser(
        description="Generate a random sentence from a text file."
    )
    parser.add_argument(
        "-f", "--filename", 
        type=str,
        default="languageModelAlpha/fish.txt",
        help="Text file to use as the word bank.")
    parser.add_argument(
        "-n", "--numSentences", 
        type=int,
        default=1,
        help="Specifies the number of sentences to generate.")
    args = parser.parse_args()
    return args.filename, args.numSentences

# get the filename
file_name,numSentences = get_filename()

# open the file and extract the lines
try:
    with open(file_name, 'r') as f:
        lines = f.readlines()
except FileNotFoundError:
    print('please enter a valid file name')
    exit()
except:
    print('something went wrong')
    exit()
vocab = tokenExtractor(lines) # build the vocab
print(vocab)
sentence = genSentence(vocab,numSentences) # construct sentence
print(sentence) # print
