import argparse

# note the . that preceeds the module names
# because these are *part of* languageModelAlpha
from .tokenExtractor import tokenExtractor
from .sentGenerator import genSentence

def get_filename():
    parser = argparse.ArgumentParser(
        description="Generate a random sentence from a text file."
    )
    parser.add_argument(
        "-f", "--filename", 
        type=str,
        default="languageModelAlpha/fish.txt",
        help="Text file to use as the word bank.")
    args = parser.parse_args()
    return args.filename

if __name__=='__main__':
    filename = get_filename()

    with open(filename, "r", encoding="utf-8") as file:
        lines = file.readlines()

    tokens = tokenExtractor(lines)
    sentence = genSentence(tokens)
    print(sentence)